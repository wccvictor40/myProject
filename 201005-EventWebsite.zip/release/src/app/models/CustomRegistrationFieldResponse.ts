﻿export interface CustomRegistrationFieldResponse {
    id: string;
    value: string;
    values: Array<string>;
}