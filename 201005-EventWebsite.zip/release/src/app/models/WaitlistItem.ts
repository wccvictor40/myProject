export interface WaitlistItem {
    id: string;
    invited: boolean;
    autoRegister: boolean;
    contact: string;
    email: string;
    event: string;
    session: string;
}
