export interface SessionRegistration {
    id: string;
    sessionName: string;
    createdon: Date;
}
