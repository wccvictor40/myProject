﻿import { CustomRegistrationFieldResponse } from "./CustomRegistrationFieldResponse";

export interface AttendeeSessions {
    sessionId: string;
    waitlisted: boolean;
}
