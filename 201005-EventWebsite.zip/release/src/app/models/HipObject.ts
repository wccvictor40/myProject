﻿export interface HipObject {
    Solution: string;
    Token: string;
    Type: string;
    FlowId: string;
}
