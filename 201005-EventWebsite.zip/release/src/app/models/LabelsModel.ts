export interface LabelsModel {
    labels: {};
    isJapanese: boolean;
}
