export interface Room {
    description: string;
    disabledAccess: boolean;
    id: string;
    name: string;
}