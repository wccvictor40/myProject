export interface Image {
    image: string;
}