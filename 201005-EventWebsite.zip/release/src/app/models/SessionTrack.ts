﻿export interface SessionTrack {
    description: string;
    id: string;
    name: string;
}