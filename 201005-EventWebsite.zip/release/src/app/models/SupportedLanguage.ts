export interface SupportedLanguage {
    label: string;
    lcid: number;
}
