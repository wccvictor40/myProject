﻿export interface RegistrationResult {
    status: string;
    errorMessage: string;
    errorCode: string;
    redirectUrl: string;
    purchaseId: string;
}
