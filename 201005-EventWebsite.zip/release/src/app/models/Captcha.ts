﻿export interface Captcha {
    FlowId: string;
    HipUrl: string;
    ObjectName: string;
    FunctionName: string;
}