export const TimeDisplayConfig = {
    is12HourFormat: true,
    showGMT: false
}